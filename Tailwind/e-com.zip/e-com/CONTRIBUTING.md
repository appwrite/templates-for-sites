# Contributing to The Organic E-Commerce Template

## Template Structure

This is a static HTML/CSS/JS e-commerce template for Appwrite Sites.

## Features
- ✅ Responsive design
- ✅ Popup authentication
- ✅ Shopping cart functionality
- ✅ Product catalog with filters
- ✅ Blog section
- ✅ Contact forms
- ✅ Smooth animations

## Development

1. Clone the repository
2. Open `index.html` in your browser
3. No build process required - pure HTML/CSS/JS

## File Structure
```
├── index.html          # Homepage
├── pages/              # All pages
├── assets/
│   ├── css/main.css    # Custom styles
│   └── js/main.js      # JavaScript functionality
└── .appwrite/
    └── template.json   # Template configuration
```

## Customization

- Update colors in Tailwind classes
- Modify product data in `assets/js/main.js`
- Add new pages following existing structure
- Customize forms and functionality as needed