// Global state
const state = {
    cart: JSON.parse(localStorage.getItem('cart')) || [],
    products: [
        { id: 1, name: 'Organic Cotton T-Shirt', price: 29.99, image: 'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=400', category: 'tops' },
        { id: 2, name: 'Sustainable Jeans', price: 79.99, image: 'https://images.unsplash.com/photo-1542272604-787c3835535d?w=400', category: 'bottoms' },
        { id: 3, name: 'Eco-Friendly Dress', price: 59.99, image: 'https://images.unsplash.com/photo-1515372039744-b8f02a3ae446?w=400', category: 'dresses' },
        { id: 4, name: 'Bamboo Hoodie', price: 49.99, image: 'https://images.unsplash.com/photo-1556821840-3a63f95609a7?w=400', category: 'tops' },
        { id: 5, name: 'Organic Linen Shirt', price: 39.99, image: 'https://images.unsplash.com/photo-1596755094514-f87e34085b2c?w=400', category: 'tops' },
        { id: 6, name: 'Recycled Polyester Jacket', price: 89.99, image: 'https://images.unsplash.com/photo-1551028719-00167b16eac5?w=400', category: 'outerwear' }
    ]
};

// Utility functions
const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => document.querySelectorAll(selector);

// Cart functions
function updateCartCount() {
    const count = state.cart.reduce((sum, item) => sum + item.quantity, 0);
    const cartCountEl = $('#cart-count');
    if (cartCountEl) cartCountEl.textContent = count;
}

function addToCart(productId) {
    const product = state.products.find(p => p.id === productId);
    if (!product) return;

    const existingItem = state.cart.find(item => item.id === productId);
    if (existingItem) {
        existingItem.quantity += 1;
    } else {
        state.cart.push({ ...product, quantity: 1 });
    }
    
    localStorage.setItem('cart', JSON.stringify(state.cart));
    updateCartCount();
    showNotification('Product added to cart!');
}

function removeFromCart(productId) {
    state.cart = state.cart.filter(item => item.id !== productId);
    localStorage.setItem('cart', JSON.stringify(state.cart));
    updateCartCount();
}

function updateQuantity(productId, quantity) {
    const item = state.cart.find(item => item.id === productId);
    if (item) {
        item.quantity = Math.max(0, quantity);
        if (item.quantity === 0) {
            removeFromCart(productId);
        } else {
            localStorage.setItem('cart', JSON.stringify(state.cart));
        }
    }
    updateCartCount();
}

// UI functions
function showNotification(message) {
    const notification = document.createElement('div');
    notification.className = 'fixed top-4 right-4 bg-gradient-to-r from-emerald-500 to-teal-600 text-white px-6 py-3 rounded-xl shadow-2xl z-50 transform translate-x-full transition-all duration-500 backdrop-blur-sm';
    notification.innerHTML = `
        <div class="flex items-center space-x-2">
            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path>
            </svg>
            <span>${message}</span>
        </div>
    `;
    document.body.appendChild(notification);
    
    setTimeout(() => notification.classList.remove('translate-x-full'), 100);
    setTimeout(() => {
        notification.classList.add('translate-x-full');
        setTimeout(() => notification.remove(), 500);
    }, 3000);
}

function renderProducts(products, containerId) {
    const container = $(containerId);
    if (!container) return;

    container.innerHTML = products.map(product => `
        <div class="group bg-white rounded-2xl shadow-lg overflow-hidden fade-in hover:shadow-2xl transition-all duration-500 hover:-translate-y-2 border border-gray-100">
            <div class="relative overflow-hidden">
                <a href="product.html?id=${product.id}">
                    <img src="${product.image}" alt="${product.name}" class="w-full h-64 object-cover group-hover:scale-110 transition-transform duration-700 cursor-pointer">
                    <div class="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                </a>
            </div>
            <div class="p-6">
                <a href="product.html?id=${product.id}">
                    <h3 class="text-lg font-semibold mb-2 text-gray-800 group-hover:text-emerald-600 transition-colors cursor-pointer">${product.name}</h3>
                </a>
                <p class="text-2xl font-bold bg-gradient-to-r from-emerald-600 to-teal-600 bg-clip-text text-transparent mb-4">$${product.price}</p>
                <div class="flex gap-2">
                    <button onclick="addToCart(${product.id})" class="flex-1 bg-gradient-to-r from-emerald-500 to-teal-600 text-white py-3 rounded-xl hover:from-emerald-600 hover:to-teal-700 transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-xl font-medium">
                        Add to Cart
                    </button>
                    <a href="product.html?id=${product.id}" class="px-4 py-3 border-2 border-emerald-500 text-emerald-600 rounded-xl hover:bg-emerald-50 transition-colors flex items-center justify-center">
                        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"></path>
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"></path>
                        </svg>
                    </a>
                </div>
            </div>
        </div>
    `).join('');
    
    // Trigger animations
    setTimeout(() => {
        $$('.fade-in').forEach((el, index) => {
            setTimeout(() => el.classList.add('visible'), index * 100);
        });
    }, 100);
}

// Page-specific functions
function initHomePage() {
    const featuredProducts = state.products.slice(0, 3);
    renderProducts(featuredProducts, '#featured-products');
}

function initShopPage() {
    renderProducts(state.products, '#products-grid');
    
    // Filter functionality
    const filterButtons = $$('.filter-btn');
    filterButtons.forEach(btn => {
        btn.addEventListener('click', () => {
            const category = btn.dataset.category;
            filterButtons.forEach(b => {
                b.classList.remove('bg-gradient-to-r', 'from-emerald-500', 'to-teal-600', 'text-white', 'shadow-lg');
                b.classList.add('bg-white/80', 'backdrop-blur-sm', 'text-gray-700', 'border', 'border-gray-200');
            });
            btn.classList.remove('bg-white/80', 'backdrop-blur-sm', 'text-gray-700', 'border', 'border-gray-200');
            btn.classList.add('bg-gradient-to-r', 'from-emerald-500', 'to-teal-600', 'text-white', 'shadow-lg');
            
            const filteredProducts = category === 'all' 
                ? state.products 
                : state.products.filter(p => p.category === category);
            renderProducts(filteredProducts, '#products-grid');
        });
    });
}

function initCartPage() {
    renderCart();
}

function renderCart() {
    const container = $('#cart-items');
    const totalEl = $('#cart-total');
    
    if (!container) return;

    if (state.cart.length === 0) {
        container.innerHTML = '<p class="text-center text-gray-500 py-8">Your cart is empty</p>';
        if (totalEl) totalEl.textContent = '$0.00';
        return;
    }

    container.innerHTML = state.cart.map(item => `
        <div class="flex items-center justify-between border-b pb-4 mb-4">
            <div class="flex items-center space-x-4">
                <img src="${item.image}" alt="${item.name}" class="w-16 h-16 object-cover rounded">
                <div>
                    <h3 class="font-semibold">${item.name}</h3>
                    <p class="text-gray-600">$${item.price}</p>
                </div>
            </div>
            <div class="flex items-center space-x-4">
                <div class="flex items-center space-x-2">
                    <button onclick="updateQuantity(${item.id}, ${item.quantity - 1})" class="w-8 h-8 rounded-full bg-gray-200 flex items-center justify-center">-</button>
                    <span class="w-8 text-center">${item.quantity}</span>
                    <button onclick="updateQuantity(${item.id}, ${item.quantity + 1})" class="w-8 h-8 rounded-full bg-gray-200 flex items-center justify-center">+</button>
                </div>
                <button onclick="removeFromCart(${item.id}); renderCart()" class="text-red-600 hover:text-red-800">Remove</button>
            </div>
        </div>
    `).join('');

    const total = state.cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    if (totalEl) totalEl.textContent = `$${total.toFixed(2)}`;
}

// Initialize page
document.addEventListener('DOMContentLoaded', () => {
    updateCartCount();
    
    // Fade in animations
    setTimeout(() => {
        $$('.fade-in').forEach(el => el.classList.add('visible'));
    }, 100);
    
    // Page-specific initialization
    const path = window.location.pathname;
    if (path.includes('shop.html')) {
        initShopPage();
    } else if (path.includes('cart.html')) {
        initCartPage();
    } else if (path === '/' || path.includes('index.html')) {
        initHomePage();
    }
});

// Export for global access
window.addToCart = addToCart;
window.removeFromCart = removeFromCart;
window.updateQuantity = updateQuantity;
window.renderCart = renderCart;